(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.diy = function() {
	this.initialize(img.diy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.elliejpgcopy = function() {
	this.initialize(img.elliejpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.scuba = function() {
	this.initialize(img.scuba);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.WEVEGOTYOU = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnB5QgJgJAAgNQAAgNAJgKQAJgJANAAQAOAAAHAJQAKAKAAANQAAANgKAJQgHAJgOAAQgNAAgJgJgAgpAqIAAgCQAAggAjgWIAXgRQALgKAAgLQAAgNgLgIQgLgHgTAAQgeAAgVAQIgOgrQAbgWAqAAQAnAAAZAUQAYAVAAAiQAAAkgkAVIgZARQgLAJAAALIAAACg");
	this.shape.setTransform(510.975,18.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAwB+Ihwi4IAAC4IgzAAIAAj7IBEAAIBvC4IAAi4IAzAAIAAD7g");
	this.shape_1.setTransform(488.05,18.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhVB+IAAj7ICrAAIAAAwIh4AAIAAAzIBeAAIAAAvIheAAIAAA5IB4AAIAAAwg");
	this.shape_2.setTransform(463.55,18.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZB+IAAjLIhIAAIAAgwIDDAAIAAAwIhIAAIAADLg");
	this.shape_3.setTransform(441.475,18.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhOB+IAAj7IAzAAIAADLIBqAAIAAAwg");
	this.shape_4.setTransform(422.325,18.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABKB+IgWg5IhnAAIgWA5Ig2AAIBkj7IA4AAIBjD7gAAhAVIghhYIghBYIBCAAg");
	this.shape_5.setTransform(398.9,18.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AA2B+IAAhpIhrAAIAABpIgzAAIAAj7IAzAAIAABjIBrAAIAAhjIAzAAIAAD7g");
	this.shape_6.setTransform(372.825,18.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAoB+Ig7hYIggAAIAABYIgyAAIAAj7IBoAAQAqAAAZAXQAXAWAAAlQAAAcgOATQgPAVgbAIIBBBdgAgzgGIA2AAQASAAALgKQALgKAAgPQAAgRgLgJQgLgKgSAAIg2AAg");
	this.shape_7.setTransform(348.25,18.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhVB+IAAj7ICrAAIAAAwIh4AAIAAAzIBdAAIAAAvIhdAAIAAA5IB4AAIAAAwg");
	this.shape_8.setTransform(325,18.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZB+IAAjLIhIAAIAAgwIDDAAIAAAwIhIAAIAADLg");
	this.shape_9.setTransform(294.475,18.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhcBeQgjgkAAg6QAAg5AjgkQAkgkA4AAQA5AAAkAkQAjAkAAA5QAAA6gjAkQgkAkg5AAQg4AAgkgkgAg3g7QgVAXAAAkQAAAlAVAWQAWAXAhAAQAiAAAVgXQAWgWAAglQAAgkgWgXQgVgWgiAAQghAAgWAWg");
	this.shape_10.setTransform(269.55,18.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhlB+IAAj7IBsAAQAnAAAWATQAXATAAAfQAAAggaATQAlASAAApQAAAhgXATQgYAUgoAAgAgyBOIBBAAQARAAAJgIQAKgIAAgNQAAgNgKgIQgJgIgRAAIhBAAgAgygYIA5AAQAPAAAJgHQAIgHAAgNQAAgLgIgIQgJgHgPAAIg5AAg");
	this.shape_11.setTransform(244.025,18.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhVB+IAAj7ICrAAIAAAwIh4AAIAAAzIBeAAIAAAvIheAAIAAA5IB4AAIAAAwg");
	this.shape_12.setTransform(220.9,18.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhIBfQgjgkAAg7QAAg6AjgkQAjgjA4AAQAyAAAgAXIgOAuQgdgVglAAQgiAAgWAWQgVAWAAAlQAAAmAVAWQAVAWAjAAQATAAARgGIAAgvIgtAAIAAgvIBgAAIAAB2QgfAeg6AAQg4AAgjgjg");
	this.shape_13.setTransform(196.675,18.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAwB+Ihwi4IAAC4IgyAAIAAj7IBDAAIBvC4IAAi4IAzAAIAAD7g");
	this.shape_14.setTransform(170.1,18.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABKB+IgWg5IhnAAIgWA5Ig2AAIBkj7IA3AAIBkD7gAAiAVIgihYIghBYIBDAAg");
	this.shape_15.setTransform(143.05,18.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAvB+Ihui4IAAC4Ig0AAIAAj7IBFAAIBuC4IAAi4IA0AAIAAD7g");
	this.shape_16.setTransform(107.4,18.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgZB+IAAj7IAzAAIAAD7g");
	this.shape_17.setTransform(87.7,18.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhVB+IAAj7ICrAAIAAAwIh4AAIAAAzIBeAAIAAAvIheAAIAAA5IB4AAIAAAwg");
	this.shape_18.setTransform(72.15,18.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhVB+IAAj7ICrAAIAAAwIh4AAIAAAzIBeAAIAAAvIheAAIAAA5IB4AAIAAAwg");
	this.shape_19.setTransform(42.1,18.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgZB+IAAj7IAyAAIAAD7g");
	this.shape_20.setTransform(25.35,18.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhbBwIAMgvQAfASAlAAQAXAAAOgIQAOgIAAgNQAAgOgUgIIgsgPQgegKgOgNQgVgSAAgfQAAgjAZgUQAYgTAqAAQAwAAAeARIgLAwQgegRgiAAQgqAAAAAZQAAAPAUAKIAsAPQAeAJAOAMQAVASAAAdQAAAlgcAVQgbAUgvAAQgwAAghgSg");
	this.shape_21.setTransform(9.425,18.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAwB+Ihwi4IAAC4IgzAAIAAj7IBEAAIBvC4IAAi4IAzAAIAAD7g");
	this.shape_22.setTransform(-24.5,18.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhVB+IAAj7ICrAAIAAAwIh4AAIAAAzIBeAAIAAAvIheAAIAAA5IB4AAIAAAwg");
	this.shape_23.setTransform(-49,18.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgZB+IAAjLIhIAAIAAgwIDDAAIAAAwIhIAAIAADLg");
	this.shape_24.setTransform(-71.075,18.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AA2B+IAAhpIhrAAIAABpIgzAAIAAj7IAzAAIAABjIBrAAIAAhjIAzAAIAAD7g");
	this.shape_25.setTransform(-95.125,18.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhEBfQgkgkAAg7QAAg6AkgkQAjgjA3AAQAzAAAfAXIgNAvQgcgWgmAAQgjAAgVAWQgWAWABAlQgBAmAWAWQAVAWAjAAQAlAAAdgWIANAvQgfAXgzAAQg3AAgjgjg");
	this.shape_26.setTransform(-119.95,18.575);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhbB+QgkgkAAg5QAAg6AkgkQAjgkA4AAQA5AAAjAkQAkAkAAA6QAAA5gkAkQgjAlg5gBQg4ABgjglgAg2gbQgWAYAAAkQAAAkAWAWQAVAYAhAAQAiAAAVgYQAWgWAAgkQAAgkgWgYQgVgWgiAAQghAAgVAWgAASh0QgHgHgBgMQABgLAHgIQAHgHAMgBQAMABAHAHQAHAIABALQgBAMgHAHQgHAHgMABQgLgBgIgHgAg4h0QgIgHABgMQgBgLAIgIQAIgHAMgBQALABAIAHQAHAIAAALQAAAMgHAHQgIAHgLABQgMgBgIgHg");
	this.shape_27.setTransform(-145.95,15.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ABdB+IAAi3IhUCNIgSAAIhUiNIAAC3IgzAAIAAj7IBEAAIBMCAIBMiAIBFAAIAAD7g");
	this.shape_28.setTransform(-177.3,18.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.WEVEGOTYOU, new cjs.Rectangle(-196.3,-6.3,718.5,50.199999999999996), null);


(lib.scubbbba = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.scuba();
	this.instance.parent = this;
	this.instance.setTransform(-150,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.scubbbba, new cjs.Rectangle(-150,-300,300,600), null);


(lib.peopleewhocare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMBHQgGgGAAgIQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGAAAHQAAAIgGAGQgFAFgIAAQgHAAgFgFgAgLAYIgDhjIAdAAIgDBjg");
	this.shape.setTransform(202.125,49.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAsBLIgNgiIg9AAIgNAiIggAAIA7iVIAhAAIA7CVgAAUAMIgUgzIgTAzIAnAAg");
	this.shape_1.setTransform(191.55,49.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BLIAAiVIAwAAQAkAAAVAVQAUAUAAAhQAAAigUAUQgVAVgkAAgAgfAuIARAAQAWAAANgMQALgNAAgVQAAgUgLgMQgNgNgWAAIgRAAg");
	this.shape_2.setTransform(176.85,49.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgyBLIAAiVIBlAAIAAAdIhGAAIAAAeIA3AAIAAAcIg3AAIAAAhIBGAAIAAAdg");
	this.shape_3.setTransform(157.8,49.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_4.setTransform(147.875,49.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag2BDIAHgcQATAKAVAAQAOAAAIgFQAJgEAAgIQAAgIgMgFIgagJQgSgGgIgHQgNgLAAgSQAAgVAPgMQAPgLAYAAQAcAAATAKIgHAcQgSgKgUAAQgZAAAAAPQAAAJAMAGIAZAJQASAGAJAGQAMALAAARQAAAWgQAMQgQAMgbAAQgeAAgTgKg");
	this.shape_5.setTransform(138.4,49.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAYBLIgjg1IgSAAIAAA1IgfAAIAAiVIA+AAQAZAAAPAOQAOANAAAWQAAARgJALQgJAMgQAEIAnA4gAgdgDIAfAAQALAAAGgGQAGgGAAgJQAAgKgGgFQgGgGgLAAIgfAAg");
	this.shape_6.setTransform(120.025,49.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtBQQgQgRgBgfIAAhWIAfAAIAABTQAAAnAfAAQAgAAAAgnIAAhTIAeAAIAABWQAAAfgPARQgRAQgeABQgdgBgQgQgAALhEQgEgEgBgIQABgGAEgFQAEgFAIAAQAGAAAEAFQAFAFAAAGQAAAIgFAEQgEAEgGAAQgIAAgEgEgAgghEQgFgEAAgIQAAgGAFgFQAEgFAHAAQAHAAAEAFQAFAFAAAGQAAAIgFAEQgEAEgHAAQgHAAgEgEg");
	this.shape_7.setTransform(104.75,47.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgzBLIAAiVIBnAAIAAAdIhIAAIAAAlIA6AAIAAAbIg6AAIAAA4g");
	this.shape_8.setTransform(91.475,49.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag+BLIAAiVIAwAAQAkAAAVAVQAUAUAAAhQAAAigUAUQgVAVgkAAgAggAuIASAAQAXAAAMgMQAMgNAAgVQAAgUgMgMQgMgNgXAAIgSAAg");
	this.shape_9.setTransform(72.5,49.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAcBLIhBhtIAABtIgfAAIAAiVIApAAIBBBtIAAhtIAfAAIAACVg");
	this.shape_10.setTransform(56.025,49.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_11.setTransform(44.375,49.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag2BDIAHgcQATAKAVAAQAOAAAJgFQAIgEAAgIQAAgIgMgFIgagJQgSgGgIgHQgNgLAAgSQAAgVAPgMQAPgLAYAAQAcAAATAKIgHAcQgSgKgUAAQgZAAAAAPQAAAJAMAGIAaAJQASAGAIAGQAMALAAARQAAAWgQAMQgQAMgbAAQgeAAgTgKg");
	this.shape_12.setTransform(34.9,49.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag2BDIAHgcQATAKAWAAQANAAAIgFQAJgEAAgIQAAgIgMgFIgagJQgSgGgIgHQgNgLAAgSQAAgVAPgMQAPgLAYAAQAcAAATAKIgHAcQgSgKgUAAQgZAAAAAPQAAAJAMAGIAZAJQASAGAJAGQAMALAAARQAAAWgQAMQgQAMgbAAQgdAAgUgKg");
	this.shape_13.setTransform(252.35,27.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAcBLIhBhtIAABtIgfAAIAAiVIApAAIBBBtIAAhtIAfAAIAACVg");
	this.shape_14.setTransform(237.275,27.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag2A4QgVgVAAgjQAAghAVgWQAVgVAhAAQAiAAAUAVQAWAWAAAhQAAAjgWAVQgUAVgiAAQghAAgVgVgAgggiQgNANAAAVQAAAWANANQANAOATAAQAUAAANgOQAMgNAAgWQAAgVgMgNQgNgOgUAAQgTAAgNAOg");
	this.shape_15.setTransform(220.3,27.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_16.setTransform(208.725,27.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag5BLIAAiVIA+AAQAYAAAPAOQAOAOAAAWQAAAWgOAMQgPAOgYAAIggAAIAAAzgAgbgEIAgAAQALAAAGgFQAGgGAAgJQAAgKgGgFQgGgGgLAAIggAAg");
	this.shape_17.setTransform(199.075,27.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AA3BLIAAhtIgyBUIgJAAIgyhTIAABsIgfAAIAAiVIApAAIAsBMIAthMIApAAIAACVg");
	this.shape_18.setTransform(181.375,27.825);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAsBLIgNgiIg9AAIgNAiIggAAIA7iVIAhAAIA7CVgAAUAMIgUgzIgTAzIAnAAg");
	this.shape_19.setTransform(163.55,27.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAgBLIAAg+Ig/AAIAAA+IgeAAIAAiVIAeAAIAAA7IA/AAIAAg7IAeAAIAACVg");
	this.shape_20.setTransform(148.05,27.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgoA4QgVgVAAgjQAAgiAVgVQAVgVAgAAQAeAAATAOIgIAbQgRgNgXAAQgTAAgNANQgNAOAAAVQAAAXANANQANANATAAQAWAAASgNIAIAbQgTAOgeAAQggAAgVgVg");
	this.shape_21.setTransform(133.3,27.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgyBLIAAiVIBlAAIAAAdIhGAAIAAAeIA3AAIAAAcIg3AAIAAAhIBGAAIAAAdg");
	this.shape_22.setTransform(115.15,27.825);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAYBLIgjg1IgSAAIAAA1IgfAAIAAiVIA+AAQAZAAAPAOQAOANAAAWQAAARgJALQgJAMgQAEIAnA4gAgdgDIAfAAQALAAAGgGQAGgGAAgJQAAgKgGgFQgGgGgLAAIgfAAg");
	this.shape_23.setTransform(101.725,27.825);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAsBLIgNgiIg9AAIgNAiIggAAIA7iVIAhAAIA7CVgAAUAMIgUgzIgTAzIAnAAg");
	this.shape_24.setTransform(86.4,27.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgoA4QgVgVAAgjQAAgiAVgVQAUgVAhAAQAeAAATAOIgJAbQgQgNgXAAQgTAAgNANQgNAOAAAVQAAAXANANQANANATAAQAXAAAQgNIAJAbQgTAOgeAAQggAAgVgVg");
	this.shape_25.setTransform(72,27.825);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgyBLIAAiVIBlAAIAAAdIhGAAIAAAeIA3AAIAAAcIg3AAIAAAhIBGAAIAAAdg");
	this.shape_26.setTransform(53.85,27.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAYBLIgjg1IgSAAIAAA1IgfAAIAAiVIA+AAQAZAAAPAOQAOANAAAWQAAARgJALQgJAMgQAEIAnA4gAgdgDIAfAAQALAAAGgGQAGgGAAgJQAAgKgGgFQgGgGgLAAIgfAAg");
	this.shape_27.setTransform(40.375,27.825);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgyBLIAAiVIBlAAIAAAdIhGAAIAAAeIA2AAIAAAcIg2AAIAAAhIBGAAIAAAdg");
	this.shape_28.setTransform(26.6,27.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Ag2BDIAIgcQASAKAVAAQAOAAAJgFQAIgEAAgIQAAgIgMgFIgagJQgRgGgKgHQgLgLgBgSQAAgVAPgMQAOgLAZAAQAdAAARAKIgGAcQgSgKgVAAQgYAAAAAPQAAAJAMAGIAaAJQASAGAIAGQAMALAAARQAAAWgQAMQgQAMgcAAQgdAAgTgKg");
	this.shape_29.setTransform(13.55,27.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAcBLIhBhtIAABtIgfAAIAAiVIApAAIBBBtIAAhtIAfAAIAACVg");
	this.shape_30.setTransform(-1.575,27.825);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgtA7QgQgRgBgfIAAhWIAfAAIAABTQAAAnAfAAQAgAAAAgnIAAhTIAeAAIAABWQAAAfgPARQgRARgeAAQgdAAgQgRg");
	this.shape_31.setTransform(-17.65,27.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.peopleewhocare, new cjs.Rectangle(-26.5,12.8,286.5,51.8), null);


(lib.HEALTHISURANCE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape.setTransform(233.325,9.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkA3IAAhsIBJAAIAAAUIgzAAIAAAWIAoAAIAAAUIgoAAIAAAZIAzAAIAAAVg");
	this.shape_1.setTransform(222.725,9.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfApQgPgPAAgaQAAgZAPgPQAPgPAYAAQAWgBAOALIgGAUQgMgJgRAAQgOAAgKAJQgJAJAAAQQAAARAJAJQAKAKAOAAQAIgBAIgCIAAgVIgUAAIAAgTIAqAAIAAAzQgOANgZgBQgYAAgPgPg");
	this.shape_2.setTransform(212.25,9.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape_3.setTransform(200.725,9.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggArQgNgNAAgWIAAg+IAXAAIAAA8QAAAcAWABQAYgBgBgcIAAg8IAXAAIAAA+QAAAWgMANQgMAMgWAAQgVAAgLgMg");
	this.shape_4.setTransform(189,9.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AARA3IgZgmIgNAAIAAAmIgWAAIAAhsIAtAAQASgBAKALQAKAJAAAQQAAAMgGAIQgHAIgLAEIAcApgAgVgCIAXAAQAHAAAFgFQAFgEAAgGQAAgIgFgDQgFgFgHAAIgXAAg");
	this.shape_5.setTransform(178.65,9.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgkA3IAAhsIBJAAIAAAUIgzAAIAAAWIAoAAIAAAUIgoAAIAAAZIAzAAIAAAVg");
	this.shape_6.setTransform(168.575,9.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAXA3IAAguIgtAAIAAAuIgXAAIAAhsIAXAAIAAAqIAtAAIAAgqIAWAAIAABsg");
	this.shape_7.setTransform(157.85,9.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdApQgPgPAAgaQAAgZAPgPQAPgPAYAAQAVgBAOALIgGAUQgMgJgQAAQgOAAgKAJQgJAJAAAQQAAARAJAJQAJAKAPAAQAQAAAMgKIAGAUQgOAKgVAAQgYAAgPgPg");
	this.shape_8.setTransform(147.125,9.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgKA3IAAhsIAVAAIAABsg");
	this.shape_9.setTransform(139.725,9.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgnAxIAFgVQAOAIAPAAQAKAAAGgEQAGgDAAgGQAAgFgJgFIgSgFQgNgFgGgFQgJgIAAgNQAAgPALgJQAKgJASABQAUAAAOAHIgFAVQgNgIgPABQgSgBAAALQAAAHAJAEIASAGQANAEAHAFQAJAIAAAMQAAARgNAIQgLAKgUgBQgVAAgOgHg");
	this.shape_10.setTransform(132.875,9.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASA3IgagmIgNAAIAAAmIgWAAIAAhsIAsAAQASgBALALQAKAJAAAQQABAMgHAIQgGAIgMAEIAdApgAgVgCIAWAAQAJAAAEgFQAEgEABgGQgBgIgEgDQgEgFgJAAIgWAAg");
	this.shape_11.setTransform(123.15,9.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgkA3IAAhsIBJAAIAAAUIgzAAIAAAWIAoAAIAAAUIgoAAIAAAZIAzAAIAAAVg");
	this.shape_12.setTransform(113.125,9.75);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgLA3IgshsIAYAAIAfBSIAghSIAYAAIgsBsg");
	this.shape_13.setTransform(102.475,9.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape_14.setTransform(90.525,9.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgkA3IAAhsIBJAAIAAAUIgzAAIAAAWIAoAAIAAAUIgoAAIAAAZIAzAAIAAAVg");
	this.shape_15.setTransform(79.925,9.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAWA3IgjguIgNANIAAAhIgWAAIAAhsIAWAAIAAAvIAsgvIAdAAIgvAwIAyA8g");
	this.shape_16.setTransform(69.9,9.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape_17.setTransform(57.575,9.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAgA3IgKgZIgsAAIgJAZIgXAAIArhsIAXAAIArBsgAAPAJIgPglIgOAlIAdAAg");
	this.shape_18.setTransform(45.85,9.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AASA3IgagmIgNAAIAAAmIgWAAIAAhsIAsAAQASgBALALQAKAJAAAQQABAMgHAIQgGAIgMAEIAdApgAgVgCIAWAAQAJAAAEgFQAEgEABgGQgBgIgEgDQgEgFgJAAIgWAAg");
	this.shape_19.setTransform(35.4,9.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAVA3IgjguIgMANIAAAhIgXAAIAAhsIAXAAIAAAvIAsgvIAdAAIguAwIAwA8g");
	this.shape_20.setTransform(24.7,9.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgkA3IAAhsIBJAAIAAAUIgzAAIAAAWIAoAAIAAAUIgoAAIAAAZIAzAAIAAAVg");
	this.shape_21.setTransform(10.475,9.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AghA3IAAhsIAWAAIAABXIAtAAIAAAVg");
	this.shape_22.setTransform(1.925,9.75);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAgA3IgJgZIgsAAIgKAZIgYAAIArhsIAZAAIArBsgAAOAJIgOglIgNAlIAbAAg");
	this.shape_23.setTransform(-8.2,9.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape_24.setTransform(-19.975,9.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgnApQgPgQAAgZQAAgYAPgQQAPgPAYAAQAYAAAQAPQAPAQAAAYQAAAZgPAQQgQAPgYAAQgYAAgPgPgAgXgZQgKAKAAAPQAAAQAKAKQAJAKAOAAQAPAAAJgKQAKgKAAgQQAAgPgKgKQgJgJgPAAQgOAAgJAJg");
	this.shape_25.setTransform(-32.35,9.75);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgKA3IAAhsIAVAAIAABsg");
	this.shape_26.setTransform(-40.775,9.75);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgKA3IAAhYIgfAAIAAgUIBTAAIAAAUIgfAAIAABYg");
	this.shape_27.setTransform(-47.725,9.75);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAgA3IgKgZIgsAAIgJAZIgXAAIAqhsIAYAAIAsBsgAAOAJIgOglIgOAlIAcAAg");
	this.shape_28.setTransform(-57.85,9.75);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape_29.setTransform(-69.575,9.75);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AASA3IgagmIgNAAIAAAmIgWAAIAAhsIAsAAQASgBALALQAKAJAAAQQABAMgHAIQgGAIgMAEIAdApgAgVgCIAWAAQAJAAAEgFQAEgEABgGQgBgIgEgDQgEgFgJAAIgWAAg");
	this.shape_30.setTransform(-80.7,9.75);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgkA3IAAhsIBJAAIAAAUIgzAAIAAAWIAoAAIAAAUIgoAAIAAAZIAzAAIAAAVg");
	this.shape_31.setTransform(-90.725,9.75);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgKA3IAAhYIgfAAIAAgUIBTAAIAAAUIgfAAIAABYg");
	this.shape_32.setTransform(-100.275,9.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAUA3IgvhQIAABQIgWAAIAAhsIAdAAIAwBPIAAhPIAWAAIAABsg");
	this.shape_33.setTransform(-111.125,9.75);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgKA3IAAhsIAVAAIAABsg");
	this.shape_34.setTransform(-119.625,9.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HEALTHISURANCE, new cjs.Rectangle(-123.7,-2,365.1,23.7), null);


(lib.ELLIE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.elliejpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ELLIE, new cjs.Rectangle(-150,-125,300,250), null);


(lib.DIY = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.diy();
	this.instance.parent = this;
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.DIY, new cjs.Rectangle(-150,-125,300,250), null);


(lib.CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAKAbIgXgmIAAAmIgLAAIAAg1IAPAAIAXAnIAAgnIALAAIAAA1g");
	this.shape.setTransform(94.175,273.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgSAbIAAg1IAlAAIAAAKIgZAAIAAALIATAAIAAAKIgTAAIAAALIAZAAIAAALg");
	this.shape_1.setTransform(88.65,273.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgEAbIAAgrIgQAAIAAgKIApAAIAAAKIgPAAIAAArg");
	this.shape_2.setTransform(83.6,273.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgQAbIAAg1IALAAIAAAqIAWAAIAAALg");
	this.shape_3.setTransform(79.25,273.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAPAbIgEgMIgVAAIgFAMIgLAAIAVg1IALAAIAWA1gAAHAFIgHgSIgGASIANAAg");
	this.shape_4.setTransform(73.9,273.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AALAbIAAgWIgVAAIAAAWIgLAAIAAg1IALAAIAAAVIAVAAIAAgVIAMAAIAAA1g");
	this.shape_5.setTransform(68,273.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAIAbIgLgTIgHAAIAAATIgLAAIAAg1IAVAAQAJAAAGAFQAFAFAAAHQAAAGgDAEQgDAEgGACIAOAUgAgKgBIAKAAQAEABADgCQACgCAAgEQAAgEgCgBQgDgDgEAAIgKAAg");
	this.shape_6.setTransform(62.45,273.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSAbIAAg1IAkAAIAAAKIgZAAIAAALIATAAIAAAKIgTAAIAAALIAZAAIAAALg");
	this.shape_7.setTransform(57.2,273.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgEAbIAAgrIgQAAIAAgKIApAAIAAAKIgQAAIAAArg");
	this.shape_8.setTransform(50.05,273.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgTAUQgIgHAAgNQAAgLAIgIQAHgIAMAAQAMAAAIAIQAHAIAAALQAAANgHAHQgIAIgMAAQgMAAgHgIgAgLgLQgFAEABAHQgBAIAFAFQAEAEAHAAQAHAAAFgEQAFgFgBgIQABgHgFgEQgFgGgHAAQgHAAgEAGg");
	this.shape_9.setTransform(44.45,273.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgVAbIAAg1IAWAAQAJAAAFAEQAEAEAAAHQAAAGgFAFQAIADAAAIQAAAHgFAFQgFAEgJAAgAgKAQIANAAQAEAAACgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAgBQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgBgEAAIgNAAgAgKgEIALAAQAEAAACgCQAAAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgCgCgEAAIgLAAg");
	this.shape_10.setTransform(38.675,273.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRAbIAAg1IAkAAIAAAKIgZAAIAAALIASAAIAAAKIgSAAIAAALIAZAAIAAALg");
	this.shape_11.setTransform(33.4,273.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPAUQgHgHAAgNQAAgMAHgHQAIgIALAAQALAAAGAFIgCAKQgHgEgIgBQgGABgFAEQgEAFAAAHQAAAIAEAFQAFAEAGAAIAIgBIAAgJIgKAAIAAgKIAVAAIAAAZQgHAGgMAAQgLAAgIgIg");
	this.shape_12.setTransform(27.925,273.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAKAbIgXgmIAAAmIgLAAIAAg1IAPAAIAXAnIAAgnIALAAIAAA1g");
	this.shape_13.setTransform(21.975,273.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAPAbIgEgMIgVAAIgFAMIgLAAIAVg1IALAAIAWA1gAAHAFIgHgSIgGASIANAAg");
	this.shape_14.setTransform(15.85,273.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF6600").s().p("AmvB7QgOgBAAgXIAAjGQAAgXAOAAINeAAQAPAAAAAXIAADGQAAAXgPABg");
	this.shape_15.setTransform(55.25,272.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(10.7,260.6,89.2,24.599999999999966), null);


(lib.ANYTIME = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoDHIAAlBIhyAAIAAhNIE1AAIAABNIhyAAIAAFBg");
	this.shape.setTransform(314.175,34.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgnDHIAAmOIBQAAIAAGOg");
	this.shape_1.setTransform(288.7,34.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiHDHIAAmOIEPAAIAABNIi+AAIAABQICUAAIAABMIiUAAIAABaIC+AAIAABLg");
	this.shape_2.setTransform(264.125,34.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AieDIIAAhBIDFkBIi9AAIAAhNIEtAAIAABAIjFECIDNAAIAABNg");
	this.shape_3.setTransform(227.75,34.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABADHIhfiLIgxAAIAACLIhRAAIAAmOICmAAQBDAAAmAkQAmAkAAA7QAAAsgXAfQgXAggrANIBnCTgAhQgKIBVAAQAdgBARgPQAQgPAAgZQAAgagQgPQgRgPgdAAIhVAAg");
	this.shape_4.setTransform(191.575,34.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AiHDHIAAmOIEPAAIAABNIi+AAIAABQICUAAIAABMIiUAAIAABaIC+AAIAABLg");
	this.shape_5.setTransform(154.775,34.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AinDHIAAmOIB/AAQBjABA3A3QA2A2AABZQAABbg2A1Qg3A3hjAAgAhWB8IAuAAQA/AAAhgjQAegfAAg6QAAg4geggQghgjg/ABIguAAg");
	this.shape_6.setTransform(117.8,34.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiHDHIAAmOIEPAAIAABNIi+AAIAABQICUAAIAABMIiUAAIAABaIC+AAIAABLg");
	this.shape_7.setTransform(80.425,34.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhcDCIAMhKQARAGAVAAQA2AAAAg4IAAkQIBRAAIAAEbQAAA7ghAgQghAeg6AAQgjAAgagIg");
	this.shape_8.setTransform(48.95,35.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah6CeQgsguABhSIAAjoIBRAAIAADgQgBBpBVAAQBVAAAAhpIAAjgIBSAAIAADoQgBBSgqAuQgsAthQAAQhPAAgrgtg");
	this.shape_9.setTransform(5.65,35.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AieDIIAAhBIDGkBIi9AAIAAhNIErAAIAABAIjEECIDNAAIAABNg");
	this.shape_10.setTransform(-32.85,34.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ANYTIME, new cjs.Rectangle(-53.7,-4.5,387.7,79.5), null);


(lib.alwayson = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah8DHIAAmNIBRAAIAAFCICoAAIAABLg");
	this.shape.setTransform(353.7,-223.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah8DHIAAmNIBRAAIAAFCICoAAIAABLg");
	this.shape_1.setTransform(323.45,-223.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AB1DHIgihaIikAAIgjBaIhWAAICemNIBZAAICeGNgAA1AhIg1iMIg0CMIBpAAg");
	this.shape_2.setTransform(286.275,-223.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABADHIhfiLIgxAAIAACLIhRAAIAAmNICmAAQBDgBAmAlQAmAjAAA6QAAAtgXAfQgXAggrANIBnCTgAhQgKIBVAAQAdAAARgQQAQgPAAgZQAAgagQgPQgRgQgdAAIhVAAg");
	this.shape_3.setTransform(248.125,-223.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiHDHIAAmNIEPAAIAABLIi+AAIAABRICUAAIAABMIiUAAIAABaIC+AAIAABLg");
	this.shape_4.setTransform(211.325,-223.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AigDHIAAmNICrAAQA9gBAkAfQAjAeAAAxQAAAzgpAeQA7AdAABCQAAAygkAfQgmAfhAAAgAhPB8IBmAAQAbAAAQgNQAOgMAAgVQAAgVgOgMQgQgNgbAAIhmAAgAhPgmIBaAAQAYAAAOgMQANgMAAgSQAAgUgNgLQgOgMgYAAIhaAAg");
	this.shape_5.setTransform(175.275,-223.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah6DVQgrguAAhSIAAjoIBQAAIAADgQABBpBUgBQBVABAAhpIAAjgIBRAAIAADoQAABSgrAuQgrAthQAAQhPAAgrgtgAAdi4QgMgMAAgSQAAgTAMgMQAMgMASAAQATAAALAMQAMAMAAATQAAASgMAMQgLALgTAAQgSAAgMgLgAhYi4QgMgMgBgSQABgTAMgMQALgMATAAQATAAALAMQAMAMAAATQAAASgMAMQgMALgSAAQgTAAgLgLg");
	this.shape_6.setTransform(134.55,-228.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AinDHIAAmNIB/AAQBjgBA4A4QA1A1AABaQAABcg1A0Qg4A3hjAAgAhWB8IAuAAQA/gBAhghQAfggAAg6QAAg4gfggQghgjg/AAIguAAg");
	this.shape_7.setTransform(81.95,-223.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ABLDHIiwkjIAAEjIhRAAIAAmNIBsAAICwEkIAAkkIBRAAIAAGNg");
	this.shape_8.setTransform(37.975,-223.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah6CeQgrgugBhSIAAjoIBRAAIAADgQABBpBUAAQBVAAAAhpIAAjgIBRAAIAADoQAABSgrAuQgrAthQAAQhPAAgrgtg");
	this.shape_9.setTransform(-4.95,-223.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.alwayson, new cjs.Rectangle(-27.7,-263.2,397.59999999999997,79.5), null);


// stage content:
(lib.ALLIANZ_320x50GE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_39
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAMIABgFQAEACAEAAIADgBQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBIgDgBIgGgCQgBgCAAgDQgBgEADgCQADgCAEAAQAEAAAEACIgBAFQgDgCgEAAQgEAAAAADQAAAAAAAAQAAABAAAAQABAAAAABQAAAAABAAIAEACIAFACQACABAAAEQAAAEgDACQgDACgEAAQgFAAgEgCg");
	this.shape.setTransform(188.95,-189.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgCAOIAAgWIgIAAIAAgFIAVAAIAAAFIgIAAIAAAWg");
	this.shape_1.setTransform(186.625,-189.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAMIACgFQADACAEAAIADgBQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAgBIgFgBIgEgCQgCgCAAgDQAAgEACgCQADgCAEAAQAEAAAEACIgBAFQgEgCgDAAQgEAAAAADQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAAAIAEACIAFACQACABAAAEQAAAEgDACQgDACgEAAQgFAAgEgCg");
	this.shape_2.setTransform(184.25,-189.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgCAOIAAgbIAFAAIAAAbg");
	this.shape_3.setTransform(182.475,-189.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgIAOIAAgbIAGAAIAAAWIALAAIAAAFg");
	this.shape_4.setTransform(181.025,-189.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAIAOIgCgGIgKAAIgDAGIgGAAIALgbIAFAAIALAbgAAEACIgEgIIgCAIIAGAAg");
	this.shape_5.setTransform(178.45,-189.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgCAOIAAgbIAFAAIAAAbg");
	this.shape_6.setTransform(176.475,-189.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgHAKQgDgEAAgGQAAgFADgEQAEgEAFAAQAGAAADACIgBAFQgDgCgFAAQgCAAgCACQgDADAAADQAAAEADADQACACACAAQAEAAAEgCIABAFQgDACgGAAQgEAAgFgEg");
	this.shape_7.setTransform(174.65,-189.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJAOIAAgbIASAAIAAAFIgMAAIAAAGIAJAAIAAAEIgJAAIAAAHIAMAAIAAAFg");
	this.shape_8.setTransform(172.25,-189.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgKAOIAAgbIALAAQAEAAADADQADACAAAEQAAAEgDACQgDACgEAAIgFAAIAAAKgAgEAAIAFAAIADgBIABgDIgBgCQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgFAAg");
	this.shape_9.setTransform(169.825,-189.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJAMIABgFQAEACAEAAIADgBQAAAAABAAQAAgBAAAAQAAAAAAgBQABAAAAAAQAAgBgBAAQAAAAAAgBQAAAAgBAAQAAAAAAgBIgFgBIgEgCQgDgCAAgDQAAgEADgCQACgCAEAAQAGAAADACIgCAFQgCgCgFAAQgDAAAAADQAAAAAAAAQAAABAAAAQABAAAAABQABAAAAAAIAEACIAFACQACABAAAEQAAAEgDACQgDACgEAAQgGAAgDgCg");
	this.shape_10.setTransform(167.3,-189.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAGAOIAAgMIgLAAIAAAMIgGAAIAAgbIAGAAIAAALIALAAIAAgLIAGAAIAAAbg");
	this.shape_11.setTransform(163.7,-189.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgCAOIAAgWIgIAAIAAgFIAVAAIAAAFIgIAAIAAAWg");
	this.shape_12.setTransform(161.075,-189.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgIAOIAAgbIAGAAIAAAWIALAAIAAAFg");
	this.shape_13.setTransform(159.025,-189.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAIAOIgDgGIgKAAIgCAGIgGAAIALgbIAFAAIALAbgAADACIgDgIIgDAIIAGAAg");
	this.shape_14.setTransform(156.45,-189.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgIAOIAAgbIARAAIAAAFIgMAAIAAAGIAKAAIAAAEIgKAAIAAAHIAMAAIAAAFg");
	this.shape_15.setTransform(153.95,-189.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAGAOIAAgMIgLAAIAAAMIgFAAIAAgbIAFAAIAAALIALAAIAAgLIAFAAIAAAbg");
	this.shape_16.setTransform(151.25,-189.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgIAOIAAgbIAGAAIAAAWIALAAIAAAFg");
	this.shape_17.setTransform(185.125,-195.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAIAOIgDgGIgKAAIgCAGIgGAAIALgbIAFAAIALAbgAADACIgDgIIgDAIIAGAAg");
	this.shape_18.setTransform(182.55,-195.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAFAOIgLgTIAAATIgGAAIAAgbIAIAAIALATIAAgTIAGAAIAAAbg");
	this.shape_19.setTransform(179.625,-195.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEgAgFgFQgCACAAADQAAAEACADQADACACAAQAEAAACgCQADgDAAgEQAAgDgDgCQgCgDgEAAQgCAAgDADg");
	this.shape_20.setTransform(176.5,-195.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgCAOIAAgbIAFAAIAAAbg");
	this.shape_21.setTransform(174.375,-195.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgCAOIAAgWIgIAAIAAgFIAVAAIAAAFIgIAAIAAAWg");
	this.shape_22.setTransform(172.625,-195.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAIAOIgCgGIgLAAIgCAGIgGAAIALgbIAFAAIALAbgAADACIgDgIIgCAIIAFAAg");
	this.shape_23.setTransform(170.05,-195.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAFAOIgLgTIAAATIgGAAIAAgbIAIAAIALATIAAgTIAGAAIAAAbg");
	this.shape_24.setTransform(167.125,-195.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAEAOIgFgKIgEAAIAAAKIgFAAIAAgbIAKAAQAFAAADADQACACAAAEQAAADgBABIgFAEIAHAKgAgFAAIAFAAIAEgBIABgDIgBgCQgBgBAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIgFAAg");
	this.shape_25.setTransform(164.325,-195.425);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgJAOIAAgbIASAAIAAAFIgMAAIAAAGIAJAAIAAAEIgJAAIAAAHIAMAAIAAAFg");
	this.shape_26.setTransform(161.8,-195.425);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgCAOIAAgWIgIAAIAAgFIAVAAIAAAFIgIAAIAAAWg");
	this.shape_27.setTransform(159.375,-195.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAFAOIgLgTIAAATIgGAAIAAgbIAIAAIALATIAAgTIAGAAIAAAbg");
	this.shape_28.setTransform(156.625,-195.425);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgCAOIAAgbIAFAAIAAAbg");
	this.shape_29.setTransform(154.475,-195.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(267));

	// Allianz_Care_Positive_SVG_svg
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#009482").s().p("AAVExQiCAAhLhPQhKhPAAiKQAAiMBLhXQBMhWB7AAQDzAAAAE+IAAAiIlRAAQAEBGAgAeQAhAfBGAAQAoAAAhgKQAhgKApgaIAiBtQgXAQgbAMQhPAjhXAAIgFAAgAg3iYQgVAfgBA8IChAAIAAgDQAAh4hMAAQgpAAgWAgg");
	this.shape_30.setTransform(308.1028,24.9154,0.0839,0.0839);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#009482").s().p("AiwEpIAApOICoAAIAABOIAIAAQAZgnAhgVQAggVAiAAQAcAAAZAJIAACjQgjgNglAAQgfAAgYAKQgYAJgZAXIAAGIg");
	this.shape_31.setTransform(304.0641,24.909,0.0839,0.0839);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#009482").s().p("AjQEGQgpgqAAhQQABjTEyAAIAQAAIAAgbQAAglgUgQQgVgRgrAAQgfAAghAHQgZAFgQAGQgPAGgmASIgOAHIgmhzQBwhFCVAAQAxAAAjAJQAiAJAcAUQAlAbANApQANApAABWIAAFwIipAAIAAhBIgHAAQgOAQgQAOQgxAphWAAQhNAAgogqgAgfA1QgoATAAAxQAAA7A6AAQAYABAYgLQAXgKARgUIAAhnIgeAAQgpABgjAPg");
	this.shape_32.setTransform(299.7109,24.9048,0.0839,0.0839);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#009482").s().p("AjDEqQhbhpAAiyQAAi9BghyQBfhzCeAAQBFAAA2AWQA1AWAwAvIg/CGQgjgoghgRQgggRgrAAQhRAAgsBDQgsBDAAB6QAAB5ArBBQAsBBBRAAQAfAAAcgKQAbgIASgMQASgLAdgbIA3B+Qg1Avg5AWQg5AWhGAAQiZAAhbhqg");
	this.shape_33.setTransform(294.7663,24.0954,0.0839,0.0839);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#003781").s().p("AmwGxQititAAkEQAAkDCtitQCtitEDAAQEEAACtCtQCtCtgBEDIABAAQAAEEitCtQisCtkFAAQkDAAititgAlnlrQiPCQAADbQAADdCPCQQCOCQDZAAQDbAACNiQQCPiQAAjdQAAjbiPiQQiOiRjaAAQjZAAiOCRgACkFUIAApPIBoAAQAmAAAQAQQAQAQABAnIAAIIgAhXFUIAAplQAAgggHgKQgIgJgbAAIgJAAIAAhLICbAAQAnAAAQAQQAQAQAAAnIAAKcgAlSFUIAAoIQAAgnARgQQAQgQAmAAIBoAAIAAJPg");
	this.shape_34.setTransform(285.4412,24.4309,0.0839,0.0839);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#003781").s().p("AjnEoIAAh6ID3lcIiEAAQgrAAAAAoIAAALIhFAAIAAhsQAAghAQgPQAPgQAhAAIGBAAIAAB6Ij1FYIEAAAIAAB9g");
	this.shape_35.setTransform(276.0994,24.93,0.0839,0.0839);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#003781").s().p("ABlErIAAl2QAAgtgJgPQgKgPgdAAQg2AAgtAyIAAGPIi4AAIAAneQAAgXgLgLQgKgLgXAAIgLAAIAAhDICvAAQA5AAAAA3IAAAYQA0gwAqgTQAqgTA3AAQBKAAAlApQAWAYAIAeQAHAfAABGIAAGRg");
	this.shape_36.setTransform(271.0583,24.9006,0.0839,0.0839);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#003781").s().p("Ah+EvQhMAAglgpQgkgpAAhVQAAhCAbgsQAbgqA4gXQAhgOAlgIQA2gMBXgOIAAgOQAAgmgPgQQgPgPglAAQgoAAgwAMQgxAMgtAWIgqhyQArgVAXgJQAagKAigHQBJgRBDAAQBxAAAtAtQAtAtAABxIAAEYQAAAdAKAMQAKALAYAAIAIAAIAABAIipAAQg3AAAAg3IAAgJQgcAWgQALQgPAJgTAJQgvATgwAAIgFAAgAg4AqQgZAJgJARQgJARAAAhQAAAhALAOQAKAOAYAAQAYAAAagNQAagOAXgYIAAhzQg0AJgxAUg");
	this.shape_37.setTransform(266.0928,24.9176,0.0839,0.0839);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#003781").s().p("AhCGRIAAneQAAgXgKgLQgLgKgXgBIgKAAIAAhDICzAAQAbAAAQAQQAQAQAAAcIAAISgAg+j9QgcgXgBgnQAAgoAcgWQAdgXAxAAQAyAAAdAXQAcAWAAAoQgBAogcAXQgcAWgyAAQgxAAgcgXg");
	this.shape_38.setTransform(262.0729,24.0471,0.0839,0.0839);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#003781").s().p("AhAGLIAAqkQAAgYgLgKQgKgKgXAAIgMAAIAAhFIC2AAQAbABAQAQQAQAQAAAcIAALYg");
	this.shape_39.setTransform(259.3616,24.1017,0.0839,0.0839);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#003781").s().p("AhAGLIAAqkQAAgYgLgKQgKgKgXAAIgMAAIAAhFIC1AAQAcABAQAQQAQAQAAAcIAALYg");
	this.shape_40.setTransform(256.7131,24.1017,0.0839,0.0839);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#003781").s().p("ACfGLIg1i+IjgAAIg5C+IjAgBIDPpsQAKgcADgMQADgNAAgLQAAgkgwAAIgYAAIAAhEIElAAQAjAAATAPQAVAQAJAgIDPLWgABNBLIhNkhIhYEhIClAAg");
	this.shape_41.setTransform(252.6325,24.1038,0.0839,0.0839);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AFiFQIhTAAIoVAAIhTAAIhCAAIAAgBIAAgBIAAgmIAAgJIAAgHIAAntIAAgKIAAhhIAAgBIAAgOIBCAAIBTAAIIVAAIBTAAIA6AAIAAKfg");
	this.shape_42.setTransform(280.45,21.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30}]}).wait(267));

	// Layer_38
	this.instance = new lib.HEALTHISURANCE();
	this.instance.parent = this;
	this.instance.setTransform(168.4,15.6,0.45,0.45,0,0,0,102.2,26);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(184).to({_off:false},0).wait(83));

	// ALWAYS_ON
	this.instance_1 = new lib.alwayson();
	this.instance_1.parent = this;
	this.instance_1.setTransform(132.35,83.65,0.2412,0.2412,0,0,0,64.2,15.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(125).to({_off:false},0).wait(20).to({alpha:0},2).wait(120));

	// ANYTIME
	this.instance_2 = new lib.ANYTIME();
	this.instance_2.parent = this;
	this.instance_2.setTransform(138.25,21.35,0.2412,0.2412,0,0,0,49.4,16.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(103).to({_off:false},0).wait(20).to({alpha:0},2).to({_off:true},1).wait(141));

	// Layer_5
	this.instance_3 = new lib.peopleewhocare();
	this.instance_3.parent = this;
	this.instance_3.setTransform(157.6,22.95,0.4574,0.4574,0,0,0,127.5,33.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(52).to({_off:false},0).to({regX:127.4,regY:33,scaleX:0.5027,scaleY:0.5027},43).wait(1).to({x:335.65},7,cjs.Ease.quintOut).wait(164));

	// QWEVE_GOT_YOU_COVERED
	this.instance_4 = new lib.WEVEGOTYOU();
	this.instance_4.parent = this;
	this.instance_4.setTransform(123.9,24.75,0.2637,0.2637,0,0,0,131.8,15.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).to({regX:131.7,regY:15.5,scaleX:0.2802,scaleY:0.2802},41).to({_off:true},1).wait(221));

	// box
	this.instance_5 = new lib.CTA();
	this.instance_5.parent = this;
	this.instance_5.setTransform(148.45,28.2,0.007,0.0254,0,0,0,57.2,272.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(197).to({_off:false},0).to({regX:55.5,regY:272.6,scaleX:0.8,scaleY:0.8,x:148.5},3).wait(67));

	// Layer_37_copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_171 = new cjs.Graphics().p("AG+DrQgXgXAAggQAAggAXgXQAXgXAgAAQAgAAAXAXQAXAXAAAgQAAAggXAXQgXAXggAAQggAAgXgXg");
	var mask_graphics_172 = new cjs.Graphics().p("Aj6HHQi9i8AAkLQAAkKC9i8QC9i9EJAAQELAAC9C9QC8C8AAEKQAAELi8C8Qi9C9kLAAQkJAAi9i9g");
	var mask_graphics_173 = new cjs.Graphics().p("AtXNYQliljAAn1QAAn0FiljQFjliH0AAQH1AAFjFiQFiFjAAH0QAAH1liFjQljFin1AAQn0AAljlig");
	var mask_graphics_174 = new cjs.Graphics().p("AznToQoJoJAArfQAAreIJoJQIJoJLeAAQLfAAIJIJQIJIJAALeQAALfoJIJQoJIJrfAAQreAAoJoJg");
	var mask_graphics_175 = new cjs.Graphics().p("A53Z4QqvquAAvKQAAvJKvquQKuqvPJAAQPKAAKuKvQKvKuAAPJQAAPKqvKuQquKvvKAAQvJAAquqvg");
	var mask_graphics_176 = new cjs.Graphics().p("EggIAgJQtUtVAAy0QAAyzNUtVQNVtUSzAAQS0AANVNUQNUNVAASzQAAS0tUNVQtVNUy0AAQyzAAtVtUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(171).to({graphics:mask_graphics_171,x:57.8593,y:25.7593}).wait(1).to({graphics:mask_graphics_172,x:84.8331,y:44.0081}).wait(1).to({graphics:mask_graphics_173,x:102.6333,y:44.2833}).wait(1).to({graphics:mask_graphics_174,x:99.9117,y:44.4617}).wait(1).to({graphics:mask_graphics_175,x:97.2869,y:44.7869}).wait(1).to({graphics:mask_graphics_176,x:95.0627,y:47.4127}).wait(91));

	// Layer_8
	this.instance_6 = new lib.scubbbba();
	this.instance_6.parent = this;
	this.instance_6.setTransform(52.75,32.85,0.2048,0.2048,0,0,0,0.2,0.2);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(171).to({_off:false},0).to({regX:0.5,scaleX:0.2307,scaleY:0.2307},95).wait(1));

	// Layer_26
	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(0.1,1,1).p("A8HlcMA32AAAIAZK5Mg33AAAg");
	this.shape_43.setTransform(169.65,22.875);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#017687").s().p("A7vFdIgYq5MA33AAAIAXK5g");
	this.shape_44.setTransform(169.65,22.875);

	var maskedShapeInstanceList = [this.shape_43,this.shape_44];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_44},{t:this.shape_43}]},171).wait(96));

	// Layer_37 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_97 = new cjs.Graphics().p("Ag2ENQgXgXAAggQAAggAXgXQAXgXAfAAQAgAAAXAXQAXAXAAAgQAAAggXAXQgXAXggAAQgfAAgXgXg");
	var mask_1_graphics_98 = new cjs.Graphics().p("AnBHCQi6i7AAkHQAAkGC6i7QC7i6EGAAQEHAAC7C6QC6C7AAEGQAAEHi6C7Qi7C6kHAAQkGAAi7i6g");
	var mask_1_graphics_99 = new cjs.Graphics().p("AtMNNQleleAAnvQAAnuFeleQFeleHuAAQHvAAFeFeQFeFeAAHuQAAHvleFeQleFenvAAQnuAAleleg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AzWTXQoCoBAArWQAArVICoBQIBoCLVAAQLWAAIBICQICIBAALVQAALWoCIBQoBICrWAAQrVAAoBoCg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A5hZiQqlqlAAu9QAAu8KlqlQKlqlO8AAQO9AAKlKlQKlKlAAO8QAAO9qlKlQqlKlu9AAQu8AAqlqlg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A/sftQtJtJAAykQAAyjNJtJQNJtJSjAAQSkAANJNJQNJNJAASjQAASktJNJQtJNJykAAQyjAAtJtJg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(97).to({graphics:mask_1_graphics_97,x:-0.0157,y:29.1593}).wait(1).to({graphics:mask_1_graphics_98,x:19.2721,y:49.5721}).wait(1).to({graphics:mask_1_graphics_99,x:38.6099,y:48.4599}).wait(1).to({graphics:mask_1_graphics_100,x:57.9029,y:47.3529}).wait(1).to({graphics:mask_1_graphics_101,x:77.2407,y:46.2407}).wait(1).to({graphics:mask_1_graphics_102,x:95.1305,y:47.4805}).wait(165));

	// DIY
	this.instance_7 = new lib.DIY();
	this.instance_7.parent = this;
	this.instance_7.setTransform(52.5,32.85,0.2472,0.2472,0,0,0,0.2,0.2);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(97).to({_off:false},0).to({regX:0.8,regY:0.8,scaleX:0.272,scaleY:0.272,y:36.95},77).wait(93));

	// BG
	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(0.1,1,1).p("A+TkTMA9AAAAIgZInMg9AAAAg");
	this.shape_45.setTransform(166.95,25.75);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#499583").s().p("A+sETIAYomMA9AAAAIgYImg");
	this.shape_46.setTransform(166.95,25.75);

	var maskedShapeInstanceList = [this.shape_45,this.shape_46];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_46},{t:this.shape_45}]},97).to({state:[]},122).wait(48));

	// Layer_6
	this.instance_8 = new lib.ELLIE();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-12.6,28.75,0.2088,0.2088);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(46).to({_off:false},0).to({regX:0.2,x:48.8},7,cjs.Ease.quintOut).to({regX:0,x:53.3},46).wait(168));

	// Layer_3
	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(0.1,1,1).p("AvP3DIACiPIa9AAIgCCPIElAAMgAeAiPAwSLMMAAegiPIAlAAIa9AAALGWVIgDC+I69AAIADi+");
	this.shape_47.setTransform(194.075,-85.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#59A39D").s().p("AL0FkI69AAIyeAAIgSrHISVAAMAgIAAAIRFAAIARLHg");
	this.shape_48.setTransform(189.4,22.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47}]}).wait(267));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(116.1,-222.9,290.29999999999995,324.9);
// library properties:
lib.properties = {
	id: '0A06B9318B014AB5B8219AF40280F340',
	width: 320,
	height: 50,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/diy.jpg", id:"diy"},
		{src:"images/elliejpgcopy.jpg", id:"elliejpgcopy"},
		{src:"images/scuba.jpg", id:"scuba"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0A06B9318B014AB5B8219AF40280F340'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;