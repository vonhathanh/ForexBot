/*
 Quantcast measurement tag
 Copyright (c) 2008-2017, Quantcast Corp.
*/
(function(k,g,h){var l="twitter:title og:title title author authors article:author article:authors bt:author bt:authors sailthru.author sailthru.authors sailthru.title lv:author lv:authors lv:title".split(" ");g=function(e,a,c){a=document.getElementsByTagName("meta");for(var b,d,f=0;f<a.length;f++)if(b=a[f],d=b.getAttribute("name")||b.getAttribute("property"),d==c){d=b.getAttribute("content");a=b=a=void 0;b:{a=void 0;for(a=0;a<l.length;a++)if(l[a]===c){a=!1;break b}a=!0}if(d)if(a){b=d.split(",");
for(a=0;a<b.length;a++)c=b,d=a,f=b[a].replace(/[^\w*]/g," ").replace(/^[\s\ufeff\xA0]+|[\s\ufeff\xA0]+$/g,""),c[d]=f;c=b}else c=d.replace(/[^\w*]/g," ");else c=d;e(c);return}e(!1)};h=function(e,a){var c=[],b;if("array"==={}.toString.call(a).match(/\s([a-zA-Z]+)/)[1].toLowerCase()){for(b=0;b<a.length;b++)c.push(e+"."+a[b]);return{labels:c.join(",")}}return{labels:e+"."+a}};__qc("rules",[k,null,[[h,"Article.Title"]],[[g,"exactmatch","og:title"]]],[k,null,[[h,"Article.Section"]],[[g,"exactmatch","article:section"]]],
[k,null,[[h,"Author"]],[[g,"exactmatch","article:author"]]])})("p-WSPjmcyyuDvN0",window,document);